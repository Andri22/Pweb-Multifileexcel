<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>Upload</title>
		<meta name="description" content="Sticky Table Headers Revisited: Creating functional and flexible sticky table headers" />
		<meta name="keywords" content="Sticky Table Headers Revisited" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!--[if IE]>
  		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
</head>
<body>

<style type="text/css">
  table {
    border-spacing: 0;
    border-collapse: collapse;
    
}
</style>
<div class="container">
<header>
	<h1>Data Sekolah</h1>
	<p>Upload Data Sekolah Multifile excel</p>
</header>
</div>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="files[]" id="files" multiple="" directory="" webkitdirectory="" mozdirectory="">
    <input type="submit" name="submit" value="Upload" /><br/>
    <label><input type="checkbox" name="drop" value="1" /> <u>Kosongkan tabel sql terlebih dahulu.
    </u> </label>
</form>

<?php 
//koneksi ke database, username,password  dan namadatabase menyesuaikan 
mysql_connect('localhost', 'root', '');
mysql_select_db('kelompok');
 
//memanggil file excel_reader
require "excel_reader.php";
			  	if ($_SERVER['REQUEST_METHOD'] == 'POST'){
			  		$drop = isset( $_POST["drop"] ) ? $_POST["drop"] : 0 ;
				    if($drop == 1){
				//             kosongkan tabel pegawai
				             $truncate ="TRUNCATE TABLE sekolah";
				             mysql_query($truncate);
				    };
				    foreach ($_FILES['files']['name'] as $j => $name) {
				        if (strlen($_FILES['files']['name'][$j]) > 1) {
				            if (move_uploaded_file($_FILES['files']['tmp_name'][$j],$name)) {

				                chmod($_FILES['files']['name'][$j],0777);
						    
						    	$data = new Spreadsheet_Excel_Reader($_FILES['files']['name'][$j],$name,false);
						    	echo $name;
						    
						//    menghitung jumlah baris file xls
						    	$baris = $data->rowcount($sheet_index=0);

    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
?>
<table border="1" class="container">

	<thead>
		<th>nama</th>
		<th>npsn</th>
		<th>tahun pelajaran</th>
		<th>kelas</th>
		<th>jurusan</th>
		<th>putra</th>
		<th>putri</th>
	</thead>
	<tbody>
	<?php
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      $npsn           = $data->val($i, 1);
      $nama   = $data->val($i, 2);
      $thn_pel  = $data->val($i, 3);
      $kelas  = $data->val($i, 4);
      $jurusan  = $data->val($i, 5);
      $putra  = $data->val($i, 6);
      $putri  = $data->val($i, 7);
   
 
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into sekolah(npsn,nama,thn_pel,kelas,jurusan,putra,putri)
      			values('$npsn','$nama','$thn_pel','$kelas','$jurusan','$putra','$putri')";
      $hasil = mysql_query($query);
      	echo "<tr>
			<td> ".$nama."</td>
			<td> ".$npsn." </td>
			<td> ".$thn_pel." </td>
			<td> ".$kelas." </td>
			<td> ".$jurusan." </td>
			<td> ".$putra." </td>
			<td> ".$putri." </td>
		</tr>";
    }
    ?>
     </tbody>
</table>
     
<?php
//    hapus file xls yang udah dibaca
    unlink($_FILES['files']['name'][$j]);
    			}
 		}
 	}
}
 
?>
</body>
</html>